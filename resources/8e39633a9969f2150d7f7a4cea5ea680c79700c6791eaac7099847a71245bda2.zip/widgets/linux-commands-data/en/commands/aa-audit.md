# TAGLINE

Set AppArmor profiles to audit mode

# TLDR

Put a profile into **audit mode**, so permitted actions are logged too

```sudo aa-audit [profile_name]```

Do it for **several profiles** at once

```sudo aa-audit [profile1] [profile2]```

Take a profile **back out** of audit mode

```sudo aa-audit --remove [profile_name]```

Read profiles from a **directory other than the system one**

```sudo aa-audit --dir [path/to/profiles] [profile_name]```

Apply it **again** even though the profile already has it

```sudo aa-audit --force [profile_name]```

Change the file but **leave the running policy alone**

```sudo aa-audit --no-reload [profile_name]```

# SYNOPSIS

**aa-audit** _executable_ [_executable_ ...] [_-d /path/to/profiles_] [_--no-reload_]

# DESCRIPTION

**aa-audit** configures AppArmor security profiles to operate in audit mode. In this mode, security policy is enforced and **all access attempts** (both successes and failures) are logged to the system log. This allows administrators to monitor application behavior while still enforcing security policies.

# PARAMETERS

**-d, --dir /path/to/profiles**
> Specifies the directory containing AppArmor profiles; defaults to /etc/apparmor.d

**--no-reload**
> Prevents automatic profile reloading after modifications

**-r, --remove**
> Disable audit mode for the specified profile (reverses the effect of aa-audit).

**-h, --help**
> Display help information

# CAVEATS

Audit mode generates significant log output as it records all access attempts. This can impact system performance and fill up log files quickly on busy systems.

# HISTORY

Part of the **AppArmor** application security framework, developed as an alternative to SELinux for Linux systems. AppArmor was originally developed by **Immunix** and later acquired by **Novell** in 2005.

# INSTALL

```apk: sudo apk add apparmor-utils```

```zypper: sudo zypper install apparmor-utils```

```nix: nix profile install nixpkgs#apparmor-utils```

<!-- packages: 2026-07-22 -->

# SEE ALSO

[aa-enforce](/man/aa-enforce)(8), [aa-complain](/man/aa-complain)(8), [aa-disable](/man/aa-disable)(8), [aa-status](/man/aa-status)(8), [apparmor](/man/apparmor)(7)
