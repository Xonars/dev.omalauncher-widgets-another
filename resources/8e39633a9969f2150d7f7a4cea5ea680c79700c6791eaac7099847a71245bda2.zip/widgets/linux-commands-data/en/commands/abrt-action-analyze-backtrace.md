# TAGLINE

analyze crash backtrace for duplication and quality

# TLDR

Analyze a backtrace **with verbose logging**

```abrt-action-analyze-backtrace -v```

Analyze problem data in a **given dump directory**

```abrt-action-analyze-backtrace -d [path/to/directory]```

Analyze the dump directory in the **current working directory**

```abrt-action-analyze-backtrace```

# SYNOPSIS

**abrt-action-analyze-backtrace** [_-v_] [_-d DIR_]

# DESCRIPTION

**abrt-action-analyze-backtrace** analyzes C/C++ backtraces and generates a duplication hash, backtrace rating, and identifies the crash function. The data is saved as new elements **duphash**, **rating**, and **crash_function** in the problem directory.

This tool works as a secondary analyzer after backtrace generation. The rating prevents low-quality backtraces from being reported, while the duplication hash helps identify previously filed similar crash reports.

# PARAMETERS

**-d DIR**
> Specifies the path to the problem directory; defaults to current working directory

**-v**
> Enables verbose output; can be used multiple times for increased verbosity

# CAVEATS

Requires a backtrace file to already exist in the problem directory. Typically used as part of the ABRT event pipeline rather than directly by users.

# HISTORY

Part of **ABRT** (Automatic Bug Reporting Tool), developed by Red Hat for Fedora-based systems to detect, analyze, and report application crashes.

# SEE ALSO

[abrt-cli](/man/abrt-cli)(1), [abrt-action-generate-backtrace](/man/abrt-action-generate-backtrace)(1), [abrt-action-analyze-c](/man/abrt-action-analyze-c)(1)

# RESOURCES

```[Source code](https://github.com/abrt/abrt)```

```[Documentation](https://abrt.readthedocs.io/)```

<!-- verified: 2026-06-10 -->
