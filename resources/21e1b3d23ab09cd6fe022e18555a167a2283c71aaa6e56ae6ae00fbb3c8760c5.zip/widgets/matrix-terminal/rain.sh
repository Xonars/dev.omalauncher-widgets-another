#!/usr/bin/bash
set -e
support="$HOME/.local/share/omalauncher-store/justqrius-matrix-terminal/widgets/matrix-terminal"
tic -x "$support/transparent.terminfo"
export TERM=owl-matrix-transparent
exec cmatrix -b -u 5 -C green
