# OMA Update — OMA Another main

Исходники: /root/dev.omalauncher-another (Xonars/dev.omalauncher-another).
Сборщик получает origin/main и создаёт detached worktree точно на полученном коммите.
Локальные ветки и PR не объединяются. Повторная сборка после ошибки создаёт новую копию.
Кнопки «Проверить», «Обновить», «Пересобрать APK» и автообновление сохранены.

Адаптация только для сборки на arm64-телефоне: NDK 28.2.13676358,
Build tools 37.0.0, CMake 4.4.4, arm64 NDK toolchain и суффикс версии.
Она применяется в build worktree и записывается diff в JSON рядом с APK.
Если структура Gradle изменится, сборщик остановится с объяснением.
Скрипт build-main.sh хранится рядом со сборщиком и не зависит от локальных PR.
Выполняются JVM-тесты, lint, проверка пяти runtime .so и сертификата подписи.
APK сохраняется в ~/APK; установка вручную через APK Share и браузер Android.

Перед сборкой настройки сохраняются в ~/OMA-RESTORE/.
Архив прежних доработок: ветка archive/local-pr-20261023.
Резервная копия сборщика, состояния и настроек: ~/OMA-RESTORE/main-only-20261023/.
Старые конфликтные worktree сохранены, но больше не блокируют обновления.
local-changes.md — исторический журнал архивной ветки, в новые APK не включён.

Проверка: python ~/.local/share/oma-updater/test_updater.py

28.10.2026: восстановлен исходный debug.keystore из предоставленного архива; сертификат проверен. Адаптация Gradle принимает уже настроенный ARM64-форк, проверяет applicationId dev.omalauncher.another. Выходные APK называются omalauncher-another-*.apk.
